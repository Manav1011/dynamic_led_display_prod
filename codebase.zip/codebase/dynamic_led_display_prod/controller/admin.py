from django.contrib import admin
from .models import Programs,Elements,Panel
# Register your models here.

admin.site.register(Programs)
admin.site.register(Elements)
admin.site.register(Panel)