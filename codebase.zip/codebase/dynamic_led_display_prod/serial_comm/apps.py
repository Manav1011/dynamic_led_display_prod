from django.apps import AppConfig


class SerialCommConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'serial_comm'
